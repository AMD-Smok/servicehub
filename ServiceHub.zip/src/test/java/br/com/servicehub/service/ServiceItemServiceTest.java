package br.com.servicehub.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ServiceItemServiceTest {
    @Mock ServiceItemRepository repository;
    @InjectMocks ServiceItemService service;

    @Test void findAllReturnsRepositoryResults() {
        when(repository.findAll()).thenReturn(List.of(new ServiceItem("Eletricista", "Reparos residenciais", new BigDecimal("120.00"), "Casa")));
        assertEquals(1, service.findAll().size());
        verify(repository).findAll();
    }

    @Test void findByIdThrowsWhenMissing() {
        when(repository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(org.springframework.web.server.ResponseStatusException.class, () -> service.findById(99L));
    }
}
