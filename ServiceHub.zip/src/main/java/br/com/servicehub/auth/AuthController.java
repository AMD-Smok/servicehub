package br.com.servicehub.auth;

import br.com.servicehub.user.AppUser;
import br.com.servicehub.user.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    public AuthController(UserRepository users, PasswordEncoder encoder, JwtService jwt) {
        this.users = users; this.encoder = encoder; this.jwt = jwt;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public java.util.Map<String, Object> register(@Valid @RequestBody AuthDtos.RegisterRequest request) {
        if (users.existsByEmail(request.email())) throw new ResponseStatusException(HttpStatus.CONFLICT, "E-mail já cadastrado");
        String role = request.role() == null ? "CLIENT" : request.role().toUpperCase();
        if (!java.util.Set.of("CLIENT", "PROVIDER").contains(role))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Papel permitido no cadastro: CLIENT ou PROVIDER");
        AppUser saved = users.save(new AppUser(request.email().toLowerCase(), encoder.encode(request.password()), role));
        return java.util.Map.of("id", saved.getId(), "email", saved.getEmail(), "role", saved.getRole());
    }

    @PostMapping("/login")
    public AuthDtos.TokenResponse login(@Valid @RequestBody AuthDtos.LoginRequest request) {
        AppUser user = users.findByEmail(request.email().toLowerCase())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciais inválidas"));
        if (!encoder.matches(request.password(), user.getPassword()))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciais inválidas");
        return new AuthDtos.TokenResponse(jwt.generate(user.getEmail(), user.getRole()), "Bearer");
    }
}
