package br.com.servicehub.service;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

public final class ServiceItemDtos {
    private ServiceItemDtos() {}
    public record ServiceRequest(@NotBlank @Size(max=100) String title,
                                 @NotBlank @Size(max=500) String description,
                                 @NotNull @DecimalMin("0.01") BigDecimal price,
                                 @NotBlank String category) {}
}
