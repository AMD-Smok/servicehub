package br.com.servicehub.service;

import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/services")
public class ServiceItemController {
    private final ServiceItemService service;
    public ServiceItemController(ServiceItemService service) { this.service = service; }

    @GetMapping public List<ServiceItem> all(@RequestParam(required=false) String title) {
        return title == null || title.isBlank() ? service.findAll() : service.search(title);
    }
    @GetMapping("/{id}") public ServiceItem byId(@PathVariable Long id) { return service.findById(id); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('ADMIN','PROVIDER')")
    public ServiceItem create(@Valid @RequestBody ServiceItemDtos.ServiceRequest request) { return service.create(request); }
    @PutMapping("/{id}") @PreAuthorize("hasAnyRole('ADMIN','PROVIDER')")
    public ServiceItem update(@PathVariable Long id, @Valid @RequestBody ServiceItemDtos.ServiceRequest request) {
        return service.update(id, request);
    }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('ADMIN')")
    public void delete(@PathVariable Long id) { service.delete(id); }
}
