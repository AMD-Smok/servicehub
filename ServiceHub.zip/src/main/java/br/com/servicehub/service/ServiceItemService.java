package br.com.servicehub.service;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ServiceItemService {
    private final ServiceItemRepository repository;
    public ServiceItemService(ServiceItemRepository repository) { this.repository = repository; }
    public List<ServiceItem> findAll() { return repository.findAll(); }
    public List<ServiceItem> search(String title) { return repository.findByTitleContainingIgnoreCase(title); }
    public ServiceItem findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Serviço não encontrado"));
    }
    public ServiceItem create(ServiceItemDtos.ServiceRequest request) {
        return repository.save(new ServiceItem(request.title(), request.description(), request.price(), request.category()));
    }
    public ServiceItem update(Long id, ServiceItemDtos.ServiceRequest request) {
        ServiceItem item = findById(id);
        item.setTitle(request.title()); item.setDescription(request.description());
        item.setPrice(request.price()); item.setCategory(request.category());
        return repository.save(item);
    }
    public void delete(Long id) { repository.delete(findById(id)); }
}
