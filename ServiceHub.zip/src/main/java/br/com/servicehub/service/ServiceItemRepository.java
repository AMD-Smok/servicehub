package br.com.servicehub.service;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceItemRepository extends JpaRepository<ServiceItem, Long> {
    List<ServiceItem> findByCategoryIgnoreCase(String category);
    List<ServiceItem> findByTitleContainingIgnoreCase(String title);
}
