package br.com.servicehub.graphql;

import br.com.servicehub.service.ServiceItem;
import br.com.servicehub.service.ServiceItemRepository;
import java.util.List;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

@Controller
public class ServiceGraphQlController {
    private final ServiceItemRepository repository;
    public ServiceGraphQlController(ServiceItemRepository repository) { this.repository = repository; }
    @QueryMapping
    public List<ServiceItem> services() { return repository.findAll(); }
    @QueryMapping
    public ServiceItem serviceById(@Argument Long id) {
        return repository.findById(id).orElse(null);
    }
}
