# ServiceHub API

API demonstrativa para catálogo de serviços, autenticação JWT e controle de acesso, desenvolvida com Java 21, Spring Boot, Spring Security, Spring Data JPA, PostgreSQL e GraphQL.

> Projeto de demonstração acadêmica. Antes de produção, configure segredos reais por variáveis de ambiente, revise CORS, migrações do banco, autorização por propriedade dos recursos, logs e política de erros.

## Funcionalidades
- Cadastro e login de usuários com senhas protegidas por BCrypt.
- Autenticação JWT via `Authorization: Bearer <token>`.
- Papéis `CLIENT`, `PROVIDER` e `ADMIN` (o cadastro público permite CLIENT/PROVIDER; ADMIN deve ser provisionado com segurança).
- CRUD de serviços e busca por título.
- Bean Validation e resposta de erro centralizada.
- Consulta GraphQL alternativa à REST.
- Testes unitários com JUnit e Mockito.

## Requisitos
- JDK 21
- Maven 3.9+
- Docker Desktop (ou PostgreSQL 16 instalado)

## Executar
1. Suba o PostgreSQL:
   ```bash
   docker compose up -d
   ```
2. Rode a API:
   ```bash
   mvn spring-boot:run
   ```
3. A API ficará em `http://localhost:8080`. GraphiQL: `http://localhost:8080/graphiql`.

## Exemplos de requisições

### Cadastrar usuário
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"cliente@exemplo.com","password":"SenhaForte123","role":"CLIENT"}'
```

### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"cliente@exemplo.com","password":"SenhaForte123"}'
```
Copie o campo `token` da resposta e use-o nas rotas protegidas.

### Listar serviços (público)
```bash
curl http://localhost:8080/api/services
```

### Criar serviço (token de PROVIDER)
```bash
curl -X POST http://localhost:8080/api/services \
  -H "Authorization: Bearer COLE_SEU_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Instalação elétrica","description":"Instalação e reparos residenciais","price":150.00,"category":"Casa"}'
```

### Buscar por título
```bash
curl "http://localhost:8080/api/services?title=elétrica"
```

### GraphQL
```graphql
query {
  services {
    id
    title
    description
    price
    category
  }
}
```
Envie a consulta para `POST /graphql` com JSON `{"query":"{ services { id title price category } }"}` ou use GraphiQL local.

## Rotas principais
| Método | Rota | Acesso |
|---|---|---|
| POST | `/api/auth/register` | Público |
| POST | `/api/auth/login` | Público |
| GET | `/api/services` | Público |
| GET | `/api/services/{id}` | Público |
| POST | `/api/services` | PROVIDER/ADMIN |
| PUT | `/api/services/{id}` | PROVIDER/ADMIN |
| DELETE | `/api/services/{id}` | ADMIN |
| POST | `/graphql` | Público nesta demo |

## Testes
Execute `mvn test`. Os testes incluídos verificam a busca de serviços e o comportamento quando um serviço não existe. Não declare os testes aprovados antes de executá-los no seu ambiente.

## Estrutura
- `auth/`: cadastro, login e JWT
- `config/`: segurança e tratamento de erros
- `service/`: entidade, repositório, regra de negócio e controller
- `graphql/`: consultas GraphQL
- `src/test/`: testes automatizados

## Publicar no GitHub
Crie um repositório vazio chamado `ServiceHub` e, na pasta deste projeto, execute:
```bash
git init
git add .
git commit -m "feat: cria API ServiceHub com JWT, segurança e GraphQL"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/ServiceHub.git
git push -u origin main
```
Substitua `SEU_USUARIO` pelo seu usuário do GitHub. Nunca envie senhas reais ou tokens para o repositório.
